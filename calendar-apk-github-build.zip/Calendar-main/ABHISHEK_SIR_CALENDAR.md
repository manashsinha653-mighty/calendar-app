# Abhishek Sir Calendar

A customized Android calendar based on the supplied Fossify Calendar source.

## Hindu Panchang data

The 2026 Hindu Panchang dataset is bundled offline from the supplied **2026 Drik Panchang Hindu Calendar v1.0.4** PDF. It is the Varanasi, India / Asia-Kolkata Purnimanta calendar shown in that PDF.

The day-detail screen now shows, for 2026:
- Tithi and Paksha
- Nakshatra
- Rashi
- Sunrise and sunset
- Festivals, vrat, sankranti, jayanti, amavasya/purnima and other events printed in the PDF
- Existing Fossify calendar functionality: month/week/day/year views, events, tasks, reminders, import/export and other calendar features

Tap any date in the month view to open its detailed Hindu Panchang card.

## Important limitation

The supplied PDF does **not** contain a general auspicious-muhurat (Vivah/Griha Pravesh/etc.) timetable. Therefore no unsupported muhurat times have been invented or added. The app displays all source-derived daily Panchang/event details available in the PDF.

## Build

Open the project in Android Studio and build the `fossDebug` variant. The project keeps the original Fossify build structure and dependencies.

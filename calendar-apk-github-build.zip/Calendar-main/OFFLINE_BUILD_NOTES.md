# अभिषेक Calendar — Offline edition

- App name: अभिषेक Calendar
- Panchang display location label: Dhanbad, Jharkhand, India
- 2026 Hindu calendar data is bundled in `app/src/main/assets/hindu_calendar_2026.json`.
- Government public and restricted holidays from the supplied 2026 Central Government Jharkhand holiday-list PDF are bundled in the same data. Sarhul and Karma are retained as undated notes because the supplied list says their observation date will follow the Government of Jharkhand holiday list.
- No network permission is required for the bundled Panchang/government-holiday feature. Existing Fossify calendar functionality may still use Android calendar providers normally.

## Important source limitation
The supplied Drik Panchang PDF is for Varanasi. This edition changes the displayed location label to Dhanbad as requested, but does not recompute astronomical timings (sunrise/sunset/tithi/nakshatra transition times) for Dhanbad. Those values remain source-derived.

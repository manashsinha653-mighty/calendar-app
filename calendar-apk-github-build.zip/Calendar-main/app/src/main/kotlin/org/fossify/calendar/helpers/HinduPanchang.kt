package org.fossify.calendar.helpers

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/** Offline 2026 Hindu calendar data extracted from the supplied Drik Panchang PDF. */
data class HinduDay(
    val date: String,
    val tithi: String,
    val zodiac: String,
    val nakshatra: String,
    val events: String,
    val sunrise: String,
    val sunset: String,
    val location: String,
    val calendar: String,
    val governmentHolidays: List<String>
)

object HinduPanchang {
    private var cache: Map<String, HinduDay>? = null

    fun get(context: Context, date: String): HinduDay? {
        val data = cache ?: load(context).also { cache = it }
        return data[date]
    }

    private fun load(context: Context): Map<String, HinduDay> {
        val json = context.assets.open("hindu_calendar_2026.json").use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
        }
        val records = JSONObject(json).getJSONArray("records")
        val result = HashMap<String, HinduDay>(records.length())
        for (i in 0 until records.length()) {
            val o: JSONObject = records.getJSONObject(i)
            val day = HinduDay(
                date = o.optString("date"),
                tithi = o.optString("tithi"),
                zodiac = o.optString("zodiac"),
                nakshatra = o.optString("nakshatra"),
                events = o.optString("events"),
                sunrise = o.optString("sunrise"),
                sunset = o.optString("sunset"),
                location = o.optString("location"),
                calendar = o.optString("calendar"),
                governmentHolidays = o.optJSONArray("government_holidays")?.let { arr ->
                    (0 until arr.length()).map { j ->
                        val h = arr.getJSONObject(j)
                        val prefix = if (h.optString("type") == "public") "Central Govt Holiday" else "Restricted Holiday"
                        "$prefix: ${h.optString("name")}"
                    }
                } ?: emptyList()
            )
            result[day.date] = day
        }
        return result
    }
}

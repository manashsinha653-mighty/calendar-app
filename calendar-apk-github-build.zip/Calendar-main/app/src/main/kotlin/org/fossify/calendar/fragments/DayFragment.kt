package org.fossify.calendar.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import org.fossify.calendar.R
import org.fossify.calendar.activities.MainActivity
import org.fossify.calendar.activities.SimpleActivity
import org.fossify.calendar.adapters.DayEventsAdapter
import org.fossify.calendar.databinding.FragmentDayBinding
import org.fossify.calendar.databinding.TopNavigationBinding
import org.fossify.calendar.extensions.config
import org.fossify.calendar.extensions.eventsHelper
import org.fossify.calendar.extensions.getViewBitmap
import org.fossify.calendar.extensions.printBitmap
import org.fossify.calendar.helpers.*
import org.fossify.calendar.interfaces.NavigationListener
import org.fossify.calendar.models.Event
import org.fossify.commons.extensions.*

class DayFragment : Fragment() {
    var mListener: NavigationListener? = null
    private var mTextColor = 0
    private var mDayCode = ""
    private var lastHash = 0

    private lateinit var binding: FragmentDayBinding
    private lateinit var topNavigationBinding: TopNavigationBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentDayBinding.inflate(inflater, container, false)
        topNavigationBinding = TopNavigationBinding.bind(binding.root)
        mDayCode = requireArguments().getString(DAY_CODE)!!
        setupButtons()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        updateCalendar()
    }

    private fun setupButtons() {
        mTextColor = requireContext().getProperTextColor()

        topNavigationBinding.topLeftArrow.apply {
            applyColorFilter(mTextColor)
            background = null
            setOnClickListener {
                mListener?.goLeft()
            }

            val pointerLeft = requireContext().getDrawable(org.fossify.commons.R.drawable.ic_chevron_left_vector)
            pointerLeft?.isAutoMirrored = true
            setImageDrawable(pointerLeft)
            contentDescription = getString(R.string.accessibility_previous_day)
        }

        topNavigationBinding.topRightArrow.apply {
            applyColorFilter(mTextColor)
            background = null
            setOnClickListener {
                mListener?.goRight()
            }

            val pointerRight = requireContext().getDrawable(org.fossify.commons.R.drawable.ic_chevron_right_vector)
            pointerRight?.isAutoMirrored = true
            setImageDrawable(pointerRight)
            contentDescription = getString(R.string.accessibility_next_day)
        }

        val day = Formatter.getDayTitle(requireContext(), mDayCode)
        topNavigationBinding.topValue.apply {
            text = day
            contentDescription = text
            setOnClickListener {
                (activity as MainActivity).showGoToDateDialog()
            }
            setTextColor(context.getProperTextColor())
        }
    }

    fun updateCalendar() {
        val startTS = Formatter.getDayStartTS(mDayCode)
        val endTS = Formatter.getDayEndTS(mDayCode)
        context?.eventsHelper?.getEvents(startTS, endTS) {
            receivedEvents(it)
        }
    }

    private fun receivedEvents(events: List<Event>) {
        val newHash = events.hashCode()
        if (newHash == lastHash || !isAdded) {
            return
        }
        lastHash = newHash

        val replaceDescription = requireContext().config.replaceDescription
        val sorted = ArrayList(events.sortedWith(compareBy({ !it.getIsAllDay() }, { it.startTS }, { it.endTS }, { it.title }, {
            if (replaceDescription) it.location else it.description
        })))

        activity?.runOnUiThread {
            updatePanchang()
            updateEvents(sorted)
        }
    }


    private fun updatePanchang() {
        val dateTime = Formatter.getDateTimeFromCode(mDayCode)
        val dateKey = String.format(java.util.Locale.US, "%04d-%02d-%02d", dateTime.year, dateTime.monthOfYear, dateTime.dayOfMonth)
        val day = HinduPanchang.get(requireContext(), dateKey)
        if (day == null) {
            binding.panchangCard.beGone()
            return
        }

        binding.panchangCard.beVisible()
        val textColor = requireContext().getProperTextColor()
        binding.panchangTitle.setTextColor(textColor)
        binding.panchangSubtitle.setTextColor(textColor)
        binding.panchangTithi.setTextColor(textColor)
        binding.panchangNakshatra.setTextColor(textColor)
        binding.panchangRashi.setTextColor(textColor)
        binding.panchangSun.setTextColor(textColor)
        binding.panchangEvents.setTextColor(textColor)
        binding.panchangGovernment.setTextColor(textColor)
        binding.panchangTitle.text = "हिन्दू पंचांग  •  Hindu Panchang"
        binding.panchangSubtitle.text = "${day.calendar} • ${day.location}"
        binding.panchangTithi.text = if (day.tithi.isNotEmpty()) day.tithi else "—"
        binding.panchangNakshatra.text = if (day.nakshatra.isNotEmpty()) day.nakshatra else "—"
        binding.panchangRashi.text = if (day.zodiac.isNotEmpty()) day.zodiac else "—"
        binding.panchangSun.text = "${day.sunrise.ifEmpty { "—" }}  ↑     ${day.sunset.ifEmpty { "—" }}  ↓"
        binding.panchangEvents.text = if (day.events.isNotEmpty()) day.events else "No festival / vrat listed"
        if (day.governmentHolidays.isNotEmpty()) {
            binding.panchangGovernment.beVisible()
            binding.panchangGovernment.text = "🇮🇳  " + day.governmentHolidays.joinToString("\n")
        } else {
            binding.panchangGovernment.beGone()
        }
    }

    private fun updateEvents(events: ArrayList<Event>) {
        if (activity == null)
            return

        DayEventsAdapter(activity as SimpleActivity, events, binding.dayEvents, mDayCode) {
            editEvent(it as Event)
        }.apply {
            binding.dayEvents.adapter = this
        }

        if (requireContext().areSystemAnimationsEnabled) {
            binding.dayEvents.scheduleLayoutAnimation()
        }
    }

    private fun editEvent(event: Event) {
        Intent(context, getActivityToOpen(event.isTask())).apply {
            putExtra(EVENT_ID, event.id)
            putExtra(EVENT_OCCURRENCE_TS, event.startTS)
            putExtra(IS_TASK_COMPLETED, event.isTaskCompleted())
            startActivity(this)
        }
    }

    fun printCurrentView() {
        topNavigationBinding.apply {
            topLeftArrow.beGone()
            topRightArrow.beGone()
            topValue.setTextColor(resources.getColor(org.fossify.commons.R.color.theme_light_text_color))
            (binding.dayEvents.adapter as? DayEventsAdapter)?.togglePrintMode()

            Handler().postDelayed({
                requireContext().printBitmap(binding.dayHolder.getViewBitmap())

                Handler().postDelayed({
                    topLeftArrow.beVisible()
                    topRightArrow.beVisible()
                    topValue.setTextColor(requireContext().getProperTextColor())
                    (binding.dayEvents.adapter as? DayEventsAdapter)?.togglePrintMode()
                }, 1000)
            }, 1000)
        }
    }
}
